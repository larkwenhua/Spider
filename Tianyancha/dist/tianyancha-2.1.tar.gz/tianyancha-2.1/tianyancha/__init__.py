__author__ = 'Qiao Zhang'

from tianyancha.tianyancha import Tianyancha
from tianyancha.tianyancha import WriterJson